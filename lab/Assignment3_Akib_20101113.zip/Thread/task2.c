#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
int x=1;
void *thr(char pt[]){
for (int i=0;i<5;i++){
printf("%s %d \n",pt,x++);
}
}
int main(){
	char a[]="Thread 0 prints";
	char b[]="Thread 1 prints";
	char c[]="Thread 2 prints";
	char d[]="Thread 3 prints";
	char e[]="Thread 4 prints";
	pthread_t t1,t2,t3,t4,t5;
	int x1,x2,x3,x4,x5;
	x1=pthread_create(&t1,NULL,(void *)thr,a);
	pthread_join(t1,NULL);
	x2=pthread_create(&t2,NULL,(void *)thr,b);
	pthread_join(t2,NULL);
	x3=pthread_create(&t3,NULL,(void *)thr,c);
	pthread_join(t3,NULL);
	x4=pthread_create(&t4,NULL,(void *)thr,d);
	pthread_join(t4,NULL);
	x5=pthread_create(&t5,NULL,(void *)thr,e);
	pthread_join(t5,NULL);
return 0;
}
