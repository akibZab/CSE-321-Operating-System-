#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
void *t(char ptr[100]){
	int *sum=0;
	for (int i=0;i<strlen(ptr);i++){
		sum=sum+ptr[i];
		
	}
	return sum;
	
}

int main(){
	int status;
	pthread_t th1,th2,th3;
	int i1,i2,i3;
	char message1[100];
	printf("Enter 3 names:\n");
	scanf("%[^\n]%*c",message1);
	
	char message2[100];
	scanf("%[^\n]%*c",message2);
	char message3[100];
	scanf("%[^\n]%*c",message3);
	i1=pthread_create(&th1,NULL,(void *)t,message1);
	pthread_join(th1,(void *)&status);
	int a=status;
	//printf("%d\n",a);
	i2=pthread_create(&th2,NULL,(void *)t,message2);
	pthread_join(th2,(void *)&status);
	int b=status;
	//printf("%d\n",b);
	i3=pthread_create(&th3,NULL,(void *)t,message3);
	pthread_join(th3,(void *)&status);
	int c=status;
	//printf("%d\n",c);
	
	
	if (a==b && b==c){
		printf("Youreka\n");
	}
	else if((a==b)|(a==c)|(b==c)){
		printf("Miracle\n");
	}
	else{
		printf("Hasta la vista\n");
	}
	return 0;
	
}
