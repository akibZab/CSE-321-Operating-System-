#include <stdio.h>
#include <unistd.h>
int main()
{
  int nos[10],n;
  int m;
  printf("\nEnter how many number you want to sort:");
	  scanf("%d",&n);
	  printf("\nEnter the numbers:");
	  for(m=0;m<n;m++)
	      scanf("%d",&nos[m]);
  int i,j,k,temp;
  for(i=0;i<n;i++)
  {
    for(j=i+1;j<n;j++){
        if(nos[i]>nos[j])
        {
            temp=nos[i];
            nos[i]=nos[j];
            nos[j] = temp;
        }
    }
   }

     printf("\n\nThe sort numbers are:\n");
         for(i=0;i<n;i++)
                printf("%d ",nos[i]);

}
