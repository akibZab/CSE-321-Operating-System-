#include <stdio.h>
#include <string.h>
int main ()
{
FILE *file = fopen( "a.txt", "w" );
char c[1000];
while(1){
	scanf("%s",c);
	if(strcmp(c,"-1")){
		fputs(c,file);
		fputs("\n",file);
	}
	else{
		break;
	}
}
return 0;
}
