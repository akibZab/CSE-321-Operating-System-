#include <stdio.h>
#include <unistd.h>
int main()
{
  int nos[10],n;
  int m;
  printf("\nEnter how many number you want to test :");
	  scanf("%d",&n);
	  printf("\nEnter %d Numbers:\n",n);
	  for(m=0;m<n;m++)
	      scanf("%d",&nos[m]);
  int i;
  for(i=0;i<n;i++)
  {
  if(nos[i] % 2 == 0)
        printf("%d is even.\n", nos[i]);
    else
        printf("%d is odd.\n", nos[i]);
  }

}
