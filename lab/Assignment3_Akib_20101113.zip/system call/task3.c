#include <sys/types.h>
#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
int main(){
	pid_t a,b,c;
	a=fork();
	b=fork();
	c=fork();
	int total=3;
	if(a%2!=0){
		total++ ;
		fork();
	}
	if(b%2!=0){
		total++ ;
		fork();
	}
	if(c%2!=0){
		total++;
		fork();
	}
	printf("Total process: %d\n",total);
}
