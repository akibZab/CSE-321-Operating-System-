#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int main(){
	pid_t pid;
	int a=fork();
	if (a==0){
		int b=fork();
		if (b==0){
		printf("Grandchild process ID: %d\n",getpid());}
		else{
			int c=fork();
			if(c==0){
			printf("Grandchild process ID: %d\n",getpid());}
			else{
				int d=fork();
				if (d==0){
				printf("Grandchild process ID: %d\n",getpid());}
				else{
				printf("Child process ID: %d\n",getpid());}
			}
		}
		exit(0);
	}
	else{
	pid=getpid();
	printf("Parent process ID: %d\n",pid);
	sleep(1);}
}
