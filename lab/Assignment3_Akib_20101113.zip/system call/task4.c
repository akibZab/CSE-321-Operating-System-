#include <sys/types.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int nos[10],n;
int main(void)
{
  int pid;
  int i,j;
  pid=fork();
  if(pid==0)
  {
    char *args[]={};
    execv("./sort",args); //have to compile the sort.c file immediately after the task4 file 
    printf("\n");
   }
   else{
   wait(NULL);
    char *arg[]={};
    execv("./oddeven",arg); //have to compile the oddeven.c file immediately after the task4 file and sort file
    return 0;
}
}

