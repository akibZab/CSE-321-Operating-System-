#include <sys/types.h>
#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
int main (){
	int id1,id2;
	int a=fork();
	if (a==0){
		int b=fork();
		if (b==0){
		printf("I am grandchild\n");}
		else{
		wait(NULL);
		printf("I am child\n");}
	}
	else{
	wait(NULL);
	printf("I am parent\n");}
	return 0;
}
