#include <stdio.h>
int main() {
	int a,b;
	printf("Enter the intervals with space between them: ");
	scanf("%d %d",&a,&b);
	for(int i=a;i<=b;i++){
		int c=0;
		for(int j=1;j<=i-1;j++){
			if(i%j==0){
			c+=j;
			}
		}
		if (i==c){
			printf("%d\n",i);
		}
	}
	return 0;
}
