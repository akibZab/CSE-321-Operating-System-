#include <stdio.h>
struct foods
	{
	int paratha,veg,minWater;
	};
int main() {
	struct foods food;
	int bill,price;
	printf("Quantity Of Paratha: \n");
	scanf("%d",&food.paratha);
	printf("Unit Price \n");
	scanf("%d",&price);
	bill=price*food.paratha;
	printf("Quantity Of Veg: \n");
	scanf("%d",&food.veg);
	printf("Unit Price \n");
	scanf("%d",&price);
	bill=bill+price*food.veg;
	printf("Quantity Of Mineral Water: \n");
	scanf("%d",&food.minWater);
	printf("Unit Price \n");
	scanf("%d",&price);
	bill=bill+price*food.minWater;
	printf("Number of people: \n");
	scanf("%d",&price);
	bill=(double)bill/price;
	printf("Individual people will pay: %f",(double)bill);
	return 0;
	}
