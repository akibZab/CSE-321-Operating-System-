#include <stdio.h>
#include <string.h>
#include <stdbool.h>
int main() {
char a[100];
FILE *file= fopen("yay.txt","r");
FILE *out= fopen("nay.txt","w");
fgets(a,255,file);
char b[strlen(a)];

for(int i=0,j=0;i< strlen(a);i++){
if (a[i]!=' '){
b[j]=a[i];
j++;
} else{
if(a[i+1]!=' '){
b[j]=a[i];
j++;
} else{
continue;
}
}
}
fprintf(out,b);
return 0;
}