#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
int main() {
    char a[100];
    char *p1, *p2;
    scanf("%s", a);
    int n = (strlen(a) - 1);
    p1 = a;
    p2 = p1 + n;

    while(p2 >= p1){
        if (*p2 == *p1) {
            p1++;
            p2--;
        } else {
            break;
        }
    }
    if (p1 < p2) {
        printf("Not Palindrome");
    } else {
        printf("Palindrome");
    }
    return 0;
}

