#include <stdio.h>
int main() {
    int a,b;
    char c;
   scanf("%d %d %c",&a, &b,&c);
   if(a>b){
       printf("%d",sub(a,b));
   }
    else if(a<b){
        printf("%d",add(a,b));
    }
    else{
       printf("%d",mul(a,b));
    }
    return 0;
}
int add(a,b){
    return a+b;
}
int sub(a,b){
    return a-b;
}
int mul(a,b){
    return a*b;
}
