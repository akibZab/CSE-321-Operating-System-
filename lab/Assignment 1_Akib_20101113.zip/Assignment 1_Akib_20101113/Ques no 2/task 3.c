#include <stdio.h>
#include <stdlib.h>
int main() {
char a[20];
scanf("%s",&a);
int l=0,u=0,d=0,s=0;
for(int i=0;i<strlen(a);i++){
if(a[i]>=65 && a[i]<=90){
u=1;
}
if(a[i]>=97 && a[i]<=122){
l=1;
}
if(a[i]==36 || a[i]==64 || a[i]==95|| a[i]==35  ){
s=1;
}
if(a[i]>=48 && a[i]<=57){
d=1;
}
}
if(u==1 && d==1 && s==1 && l==1 ){
printf("ok");
} else{
if(u==0){
printf("Uppercase character missing ,");
}
if(l==0){
printf("lowercase character missing ,");
}
if(d==0){
printf("digit missing," );
}
if(s==0){
printf("special character missing ");
}
}
return 0;
}

