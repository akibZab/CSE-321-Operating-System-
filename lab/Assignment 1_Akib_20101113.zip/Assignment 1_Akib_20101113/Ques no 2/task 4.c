#include <stdio.h>
#include <string.h>
#include <stdbool.h>
int main() {
char a[100];
scanf("%s",&a);
email(a);
return 0;
}
void email (char e[100]) {
char a[100] = "sheba.xyz";
char b[100];
bool flag = false;
for (int i = 0, j = 0; i < strlen(e); i++) {
if (flag) {
b[j] = e[i];
j++;
}
if (e[i] == '@') {
flag = true;
continue;
}
}
if (strcmp(a, b)) {
printf("Email address is outdated");
} else {
printf("Email address is okay");
}
}
