#include <stdio.h>
int main() {
    int n=6,m=4,count=0,i=0,j=0;
    int alloc[6][4] = {{0,1,0,3},{2,0,0,3},{3,0,2,0},{2,1,1,5},{0,0,2,2},{1,2,3,1}};
    int max[6][4] = {{6,4,3,4},{3,2,2,4},{9,1,2,6},{2,2,2,8},{4,3,3,7},{6,2,6,5}};
    int avail[4] = {2,2,2,1};
    int boolean[6]={0,0,0,0,0,0};
    int need[6][4];
    int avail2[4]={0};
    for (int i=0;i<n ;i++){
        for (int j=0;j<m ;j++){
            need[i][j]=max[i][j]-alloc[i][j];
        }
    }
    while(1){
        int x=0;
        while(x<m){
            avail2[x]=avail[x];
            x++ ;
        }
        i=0;
        while(i<n){
            if (boolean[i]==0){
                int a1 =1;
                int j=0;
                while(j<m){
                    if (need[i][j]<=avail[j]){
                        j++;
                        continue;
                    }
                    else{
                        a1 = 0;
                        break;
                    }
                    j++;
                }
                if(a1==1){
                    boolean[i]=1;
                    count++;
                    if(count!=n)
                        printf("P%d->",i);
                    else
                        printf("P%d",i);
                    int c=0;
                    while(c<m)
                    {
                        avail[c]+=alloc[i][c];
                        c++;
                    }
                }
            }
            i++;
        }
        int f=0;
        int z=0;
        while (z<m){
            if(avail2[z]!=avail[z]){
                f=1;
                break;
            }
            z++;
        }
        if(f==1){
            continue;
        }
        else{
            break;
        }
    }
}
