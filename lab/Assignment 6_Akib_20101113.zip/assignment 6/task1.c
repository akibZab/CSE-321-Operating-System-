#include <stdio.h>
int main() {
    int n=5,m=4,count=0,i=0,j=0;
    int alloc[5][4] = {{0,1,0,3},{2,0,0,0},{3,0,2,0},{2,1,1,5},{0,0,2,2}};
    int max[5][4] = {{6,4,3,4},{3,2,2,1},{9,1,2,6},{2,2,2,8},{4,3,3,7}};
    int avail[4] = {3,3,2,1};
    int need[5][4];
    int boolean[5]={0,0,0,0,0};
    int boolean1[5]={0,0,0,0,0};


    while(i<n){
        while(j<m){
            need[i][j]=max[i][j]-alloc[i][j];
            j++;
        }
        i++;
    }

    int aravail[4]={0};
    while(1){
        count++;

        int x=0;
        while(x<m){
            aravail[x]=avail[x];
            x++ ;
        }
        i=0;
        while(i<n)
        {
            if (boolean[i]==0){
                int a1 =1;
                int j=0;
                    while(j<m){
                    if (need[i][j]<=avail[j]){
                        j++;
                        continue;
                    }
                    else{
                        a1 = 0;
                        break;
                    }
                    j++;
                }
                if(a1==1){
                    boolean[i]=1;
                    int c=0;
                    while(c<m)
                    {
                        avail[c]+=alloc[i][c];
                        c++;
                    }
                }
            }
            i++;
        }
        int f=0;
        int z=0;

        while (z<m){
            if(aravail[z]!=avail[z]){
                f=1;
                break;
            }
            z++;
        }
        if(f==0){
            break;
        }
        else{
            continue;
        }
    }

    i=1;
    while (i<=n){
        if(boolean[i-1]==0){
            printf("Deadlock Ahead");
            break;
        }
        else if(i==n){
            printf("Safe Here");
        }
        i++;
    }
}
