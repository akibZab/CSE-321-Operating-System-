#include <stdio.h>
#include <pthread.h>
#include <stdbool.h>
#include <semaphore.h>
#define MaxCrops 5 // Maximum crops a Farmer can produce or a Shpoowner can take
#define warehouseSize 5 // Size of the warehouse
sem_t empty;
sem_t full;
int in = 0;
int out = 0;
char crops[warehouseSize]={'R','W','P','S','M'}; //indicating room for different crops
char warehouse[warehouseSize]={'N','N','N','N','N'}; //initially all the room is empty
pthread_mutex_t mutex;
int c1 = 0;
int c2 = 0;
pthread_mutex_t c2_mutex;

pthread_mutex_t mutex_i;
pthread_mutex_t mutex_o;
void sc1(bool x)
{
    pthread_mutex_lock(&mutex);
    if(x==true)
    {c1++;
    }else {c1--;
    }
    pthread_mutex_unlock(&mutex);
}
int gc1()
{
    pthread_mutex_lock(&c2_mutex);
    c2++;
    if(c2 == 1)
    {
        pthread_mutex_lock(&mutex);
    }
    pthread_mutex_unlock(&c2_mutex);
    pthread_mutex_lock(&c2_mutex);
    const int _c1 = c1;
    c2--;
    if(c2 == 0)
    {
        pthread_mutex_unlock(&mutex);
    }
    pthread_mutex_unlock(&c2_mutex);
    return _c1;
}

void *Farmer(void *far)
{
    int produce_c1 = 0;
    const int thread_id = *(int *)far;
    for(produce_c1=0;produce_c1<MaxCrops;produce_c1++)
    {
        while(gc1() == warehouseSize);
        sem_wait(&empty);
        pthread_mutex_lock(&mutex_i);
        warehouse[in] = crops[in];
        printf("Farmer %d: Insert crops %c at %d\n", thread_id, crops[in], in);
        in = (in + 1) % warehouseSize;
        pthread_mutex_unlock(&mutex_i);
        sc1(true);
        sem_post(&full);
    }
    printf(" Farmer %d: ", thread_id);
    int i=0;
    while(i<warehouseSize)
    {
        printf(" %c ",warehouse[i]);
        i++;
    }
    printf("\n");

}

void * ShopOwner(void *sho)
{
    int produce_c1 = 0;
    const int thread_id = *(int *)sho;

    for(produce_c1=0;produce_c1<MaxCrops;produce_c1++)
    {
        while(gc1() == 0);
        sem_wait(&full);
        pthread_mutex_lock(&mutex_o);
        printf("Shop owner %d: Remove crops %c from %d\n", thread_id, warehouse[out], out);
        warehouse[out] = 'N';
        out = (out + 1) % warehouseSize;
        pthread_mutex_unlock(&mutex_o);
        sc1(false);
        sem_post(&empty);
    }
    printf(" Shop owner %d: ", thread_id);
    int i=0;
    while(i<warehouseSize)
    {
        printf(" %c ",warehouse[i]);
        i++;
    }
    printf("\n");
}

int main()
{

    pthread_t Far[5],Sho[5];
    pthread_mutex_init(&mutex, NULL);
    sem_init(&empty, 0, warehouseSize);//when the warehouse is full thread will wait
    sem_init(&full, 0, 0);//when the warehouse is empty thread will wait

    int a[5] = {1,2,3,4,5}; //Just used for numbering the Farmer and ShopOwner
    pthread_mutex_init(&c2_mutex, NULL);
    pthread_mutex_init(&mutex_i, NULL);
    pthread_mutex_init(&mutex_o, NULL);
    /*create 5 thread for Farmer 5 thread for ShopOwner
     -------------------------------------------------
     -------------------------------------------------
     */
    int i=0;
    while(i<5)
    {
        pthread_create(&Far[i], NULL, Farmer, &a[i]);
        pthread_create(&Sho[i], NULL, ShopOwner, &a[i]);
        i++;
    }
    i=0;
    while(i<5)
    {
        pthread_join(Far[i], NULL);
        i++;
    }
    i=0;
    // Closing or destroying mutex and semaphore
    pthread_mutex_destroy(&mutex);
    sem_destroy(&empty);
    sem_destroy(&full);
}



