#include <pthread.h>
#include <stdio.h>
#include <string.h>

#define BUFLEN 6
#define NUMTHREAD 2 /* number of threads */

void * consumer(int *id);
void * producer(int *id);

char buffer[BUFLEN];
char source[BUFLEN]; //from this array producer will store it's production into buffer

int pCount = 0;
int cCount = 0;
int buflen;

pthread_mutex_t count_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t nonEmpty = PTHREAD_COND_INITIALIZER;
pthread_cond_t full = PTHREAD_COND_INITIALIZER;
int thread_id[NUMTHREAD] = {0,1};
int i = 0;
int j = 0;

int main()
{
    int i;
    /* define the type to be pthread */
    pthread_t thread[NUMTHREAD];

    strcpy(source, "abcdef");
    buflen = strlen(source);

    pthread_create(&thread[0], NULL, (void *)producer, &thread[0]);
    pthread_create(&thread[1], NULL, (void *)consumer, &thread[1]);
    pthread_join(thread[0], NULL);
    pthread_join(thread[1], NULL);
    return 0;
}

void * producer(int *id)
{
    const int thread_id = *id;

    pthread_mutex_lock(&count_mutex);
    i=0;
    while(source[i] != '\0'){
            buffer[i] = source[i];
            printf(" %d produced %c by thread %d \n",i,buffer[i],(thread_id-1));
            pthread_cond_signal(&full);
            pthread_cond_wait(&nonEmpty, &count_mutex);
            i += 1;
    }
    pthread_mutex_unlock(&count_mutex);
}

void * consumer(int *id)
{
    const int thread_id = *id;


    pthread_mutex_lock(&count_mutex);
    j=0;
    while(buffer[j] != '\0'){
        if(j >= i )
        {
            if( i != buflen - 1){
            pthread_cond_signal(&nonEmpty);
            pthread_cond_wait(&full, &count_mutex);
        }
        }
        printf(" %d consumed %c by Thread %d\n",j,buffer[j],(thread_id-1));
    }

    pthread_cond_signal(&nonEmpty);
    pthread_mutex_unlock(&count_mutex);

}
